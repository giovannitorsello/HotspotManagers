<!--
- Please ask questions at https://groups.google.com/forum/#!forum/loopbackjs or
  https://gitter.im/strongloop/loopback

- Immediate support is available through our subscription plans, see
  https://strongloop.com/api-connect-faqs/
-->

### Bug or feature request

<!--
Mark your choice with an "x" (eg. [x], NOT [*]).
-->

- [ ] Bug
- [ ] Feature request

### Description of feature (or steps to reproduce if bug)



### Link to sample repo to reproduce issue (if bug)



### Expected result



### Actual result (if bug)



### Additional information (Node.js version, LoopBack version, etc)


